const config = {
    PORT: 3000,
    MONGO_URL: "mongodb+srv://DBAdmin:u_pick_it@cluster0.exo7k.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    DB_NAME: "entrega3backEnd1"
}

module.exports = {config}